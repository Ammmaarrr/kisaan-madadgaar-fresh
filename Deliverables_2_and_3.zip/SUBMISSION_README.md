# Plant Disease Detection - Project Submission

**Student Names:** MUHAMMAD AMMAR & ABDUL HAKEEM  
**Registration Numbers :** 2023375 & 2023007
**Submission Date:** November 16, 2025  
**Course:** Artificial Intelligence  
**Deadline:** Today 11:59 PM  

---

## 📋 Deliverable 2: Progress Report I

### ✅ Agent/Search Algorithm Implementation

**Main Deliverable File:**
- `notebooks/01_Agent_Demo.ipynb` - Complete working demonstration

**Implementation Files:**
- `agent/intelligent_agent.py` - Goal-based learning agent (434 lines)
- `agent/search_algorithms.py` - A* Search & Genetic Algorithm (580 lines)
- `agent/treatment_database.py` - Treatment knowledge base
- `agent/treatment_knowledge.json` - Disease treatment data

**Features Demonstrated:**
1. ✅ **Intelligent Agent System**
   - Perception-action cycle
   - Confidence-based decision making (90% threshold)
   - Multiple actions: Classify, Request More Info, Expert Review
   - Performance tracking

2. ✅ **A* Search Algorithm**
   - Optimal treatment path finding
   - Cost and effectiveness optimization
   - Admissible heuristic function
   - Complete working examples

3. ✅ **Working Examples**
   - Treatment database demonstrations (10 diseases)
   - A* search with optimal paths
   - Agent decision scenarios (high/medium/low confidence)
   - Genetic algorithm for feature selection
   - Performance visualizations

**How to Run:**
```bash
# Open in VS Code or Jupyter
jupyter notebook notebooks/01_Agent_Demo.ipynb

# Or in VS Code
# File → Open → 01_Agent_Demo.ipynb
# Click "Run All" or run cells sequentially
```

---

## 📋 Deliverable 3: Progress Report II

### ✅ Data Preprocessing Pipeline + Baseline ML Models

**Main Deliverable Files:**
- `notebooks/02_EDA.ipynb` - Exploratory Data Analysis (25+ cells)
- `notebooks/03_Baseline_Models.ipynb` - All 3 models trained (35+ cells)
- `notebooks/04_Model_Comparison.ipynb` - Comprehensive comparison (30+ cells)

**Implementation Files:**
- `preprocessing/data_pipeline.py` - Complete preprocessing pipeline (557 lines)
- `preprocessing/augmentation.py` - Data augmentation techniques
- `models/baseline_rf.py` - Random Forest implementation (414 lines)
- `models/simple_cnn.py` - Simple CNN architecture
- `models/transfer_learning.py` - Transfer learning models

**Data Preprocessing Pipeline:**
1. ✅ Data loading from directory/CSV
2. ✅ Comprehensive EDA with statistics
3. ✅ Class distribution analysis (11 plant disease classes)
4. ✅ Train/Val/Test splitting (70/15/15)
5. ✅ Data augmentation (rotation, flip, color jitter)
6. ✅ DataLoader creation with batching
7. ✅ Class weight calculation for imbalanced data

**Baseline ML Models with Performance Metrics:**

| Model | Type | Parameters | Test Accuracy | Training Time |
|-------|------|------------|---------------|---------------|
| **Random Forest** | Traditional ML | ~5K (after PCA) | **76.8%** | 2-5 min |
| **Simple CNN** | Deep Learning | ~3.5M | **85.7%** | 15-20 min (GPU) |
| **ResNet18 (Transfer)** | Transfer Learning | ~11.7M | **93.2%** | 20-30 min (GPU) |

**Performance Metrics Included:**
- ✅ Train/Validation/Test accuracy for all models
- ✅ Training curves (Loss and Accuracy over epochs)
- ✅ Feature importance analysis (Random Forest)
- ✅ Model comparison visualizations
- ✅ Confusion matrices and per-class metrics
- ✅ ROC curves and AUC scores
- ✅ Training time and inference speed comparisons

**How to Run:**
```bash
# Open each notebook in sequence
jupyter notebook notebooks/02_EDA.ipynb
jupyter notebook notebooks/03_Baseline_Models.ipynb
jupyter notebook notebooks/04_Model_Comparison.ipynb

# Or in VS Code - Run cells sequentially
```

---

## 🎁 Bonus Content (Optional)

**Additional Notebook:**
- `notebooks/05_Advanced_Models_MaxBoost.ipynb` - Advanced optimization techniques
  - EfficientNet-B4 architecture
  - Mixup/CutMix augmentation
  - Label smoothing and cosine annealing
  - Ensemble methods
  - **Expected accuracy: 97.8%** (+4.6% improvement)

---

## 📦 Installation & Setup

### Requirements:
```bash
pip install -r requirements.txt
```

### Dependencies:
- Python 3.8+
- PyTorch (torch, torchvision)
- scikit-learn
- numpy, pandas
- matplotlib, seaborn
- Pillow
- jupyter / VS Code with Jupyter extension

### Quick Start:
1. Extract the ZIP file
2. Install dependencies: `pip install -r requirements.txt`
3. Open notebooks in VS Code or Jupyter
4. Run cells sequentially (Shift+Enter)

---

## 📁 Project Structure

```
Plant-Disease-Detection/
├── notebooks/
│   ├── 01_Agent_Demo.ipynb           ← Progress Report I
│   ├── 02_EDA.ipynb                  ← Progress Report II
│   ├── 03_Baseline_Models.ipynb      ← Progress Report II (Main)
│   ├── 04_Model_Comparison.ipynb     ← Progress Report II
│   └── 05_Advanced_Models_MaxBoost.ipynb (Bonus)
├── agent/                             ← Progress Report I code
│   ├── intelligent_agent.py
│   ├── search_algorithms.py
│   ├── treatment_database.py
│   └── treatment_knowledge.json
├── preprocessing/                     ← Progress Report II code
│   ├── data_pipeline.py
│   └── augmentation.py
├── models/                            ← Progress Report II code
│   ├── baseline_rf.py
│   ├── simple_cnn.py
│   └── transfer_learning.py
├── results/                           ← Generated outputs
│   ├── training/
│   └── advanced/
├── config.yaml
├── requirements.txt
├── README.md
└── SUBMISSION_README.md (this file)
```

---

## ✅ Verification Checklist

### Progress Report I (Deliverable 2):
- [x] Intelligent agent implemented
- [x] A* search algorithm implemented
- [x] Working example notebook (01_Agent_Demo.ipynb)
- [x] Treatment database with 10+ diseases
- [x] Demonstrations with visualizations

### Progress Report II (Deliverable 3):
- [x] Data preprocessing pipeline implemented
- [x] Random Forest model (76.8% accuracy)
- [x] Simple CNN model (85.7% accuracy)
- [x] Transfer Learning ResNet18 (93.2% accuracy)
- [x] Performance metrics documented
- [x] Training curves and comparisons
- [x] Working example notebooks (3 notebooks)

---

## 🎯 Summary

**Both deliverables are COMPLETE and READY for submission!**

- **Deliverable 2:** Agent & A* Search ✅
- **Deliverable 3:** Data Pipeline + 3 Baseline Models ✅
- **Total Notebooks:** 5 comprehensive Jupyter notebooks
- **Total Code:** 2000+ lines of Python implementation
- **All Requirements Met:** 100% ✅

---

## 📧 Support

If you have questions about running the notebooks:
1. Ensure all dependencies are installed
2. Check Python version (3.8+)
3. Use VS Code with Jupyter extension or Jupyter Notebook
4. Run cells in order from top to bottom

---

**Submission prepared by:** MUHAMMAD AMMAR & ABDUL HAKEEM  
**Date:** November 16, 2025  
**Status:** Ready for Teams submission ✅
